This directory contains a simple test fixture to verify the basic packaging of Fluid Infusion as a node module
performed by the material in src/module/fluid.js . 

To run the tests, execute 

    node basic-node-test.js 

from the command line. They should terminate with the message

    Self-test OK - 3/3 tests passed

The comprehensive test suite for Infusion should be run in the browser by loading the markup file `tests/all-tests.html`
