The instance of [Foundation v5.4.5](http://foundation.zurb.com/develop/download.html) included in this directory is from an **Essentials** build,
with the following **removed**:

* css/foundation.min.css
* css/normalize.css
* humans.txt
* img
* index.html
* js/foundation.min.js
* js/vendor/jquery.js
* robots.txt

These are either already included or are not used.
