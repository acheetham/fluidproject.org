This folder contains templates shared by all of the Preferences Framework examples.
Each example only uses a few of these templates, not necessarily all.

The file SeparatedPanelPrefsEditorFrame.html will not need to be here after FLUID-5218 (http://issues.fluidproject.org/browse/FLUID-5218) is addressed.
