This folder contains JSON string bundles shared by all of the Preferences Framework examples.
Each example only uses a few of these files, not necessarily all.
